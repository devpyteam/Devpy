class A:
    def a(self):
        return 'a'