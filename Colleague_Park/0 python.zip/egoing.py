def a():
    return 'a'
def b():
    return 'b'
def c():
    return 'c'