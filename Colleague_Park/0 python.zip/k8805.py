def a():
    return 'B'